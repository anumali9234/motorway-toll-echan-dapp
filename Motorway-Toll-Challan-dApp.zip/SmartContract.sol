// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @title Motorway Toll & E-Challan Management (Student Prototype)
/// @notice Demonstrates how toll payments and traffic e-challans could be recorded
///         transparently on a blockchain. It is NOT connected to M-Tag, NHMP, NHA,
///         FWO, Raast, JazzCash, Easypaisa or any vehicle registration database.
/// @dev Payments use Sepolia test ETH only. Amounts are demo values, not real PKR.
contract MotorwayTollChallan {

    // ---------------------------------------------------------------
    // Data structures
    // ---------------------------------------------------------------
    struct Vehicle {
        address vehicleOwner;     // wallet that registered the vehicle
        uint8 vehicleClass;       // 0 = Car, 1 = Bus, 2 = Truck
        uint256 registeredAt;     // block timestamp
        uint256 tollsPaid;        // number of toll payments
        uint256 totalTollWei;     // total toll paid (wei)
        uint256 unpaidChallans;   // number of unpaid challans
    }

    struct TollRecord {
        string plate;
        address payer;
        uint8 route;              // 0 = M-2, 1 = M-1, 2 = M-3
        uint256 amount;           // wei paid
        uint256 timestamp;
    }

    struct Challan {
        string plate;
        uint8 violation;          // 0 = Over-speeding, 1 = Lane violation, 2 = No seatbelt
        uint256 fine;             // wei
        uint256 issuedAt;
        bool paid;
        uint256 paidAt;
    }

    // ---------------------------------------------------------------
    // State variables
    // ---------------------------------------------------------------
    /// @notice Deployer. Acts as the "NHMP authority" (issues challans) and
    ///         the treasury that receives all toll and fine payments.
    address public owner;

    // Demo prices in wei (Sepolia test ETH). Set in the constructor.
    uint256[3] public routeBaseFare;      // per route
    uint256[3] public classMultiplier;    // per vehicle class
    uint256[3] public violationFine;      // per violation type

    /// @notice A vehicle with this many unpaid challans cannot pay toll
    ///         until it clears them (automated business rule).
    uint256 public constant MAX_UNPAID_CHALLANS = 3;

    uint256 public tollCount;
    uint256 public challanCount;

    mapping(string => Vehicle) private vehicles;
    mapping(uint256 => TollRecord) public tollRecords;   // ids start at 1
    mapping(uint256 => Challan) public challans;         // ids start at 1

    // ---------------------------------------------------------------
    // Events (permanent, searchable logs)
    // ---------------------------------------------------------------
    event VehicleRegistered(string plate, address indexed vehicleOwner, uint8 vehicleClass);
    event TollPaid(uint256 indexed tollId, string plate, address indexed payer, uint8 route, uint256 amount);
    event ChallanIssued(uint256 indexed challanId, string plate, uint8 violation, uint256 fine);
    event ChallanPaid(uint256 indexed challanId, string plate, address indexed payer, uint256 amount);

    // ---------------------------------------------------------------
    // Constructor
    // ---------------------------------------------------------------
    constructor() {
        owner = msg.sender;

        // Route fares: M-2 Islamabad-Lahore, M-1 Islamabad-Peshawar, M-3 Pindi Bhattian-Multan
        routeBaseFare[0] = 0.0010 ether;
        routeBaseFare[1] = 0.0006 ether;
        routeBaseFare[2] = 0.0008 ether;

        // Vehicle class multipliers: Car x1, Bus x2, Truck x3
        classMultiplier[0] = 1;
        classMultiplier[1] = 2;
        classMultiplier[2] = 3;

        // Fines: Over-speeding, Lane violation, No seatbelt
        violationFine[0] = 0.0020 ether;
        violationFine[1] = 0.0010 ether;
        violationFine[2] = 0.0005 ether;
    }

    // ---------------------------------------------------------------
    // 1) WRITE: register a vehicle (needs MetaMask approval, no ETH sent)
    // ---------------------------------------------------------------
    /// @param plate Number plate, e.g. "ICT-1234" (frontend upper-cases it)
    /// @param vehicleClass 0 = Car, 1 = Bus, 2 = Truck
    function registerVehicle(string memory plate, uint8 vehicleClass) public {
        require(bytes(plate).length >= 3 && bytes(plate).length <= 15, "Plate must be 3-15 characters");
        require(vehicleClass < 3, "Invalid vehicle class");
        require(vehicles[plate].vehicleOwner == address(0), "Vehicle already registered");

        vehicles[plate] = Vehicle({
            vehicleOwner: msg.sender,
            vehicleClass: vehicleClass,
            registeredAt: block.timestamp,
            tollsPaid: 0,
            totalTollWei: 0,
            unpaidChallans: 0
        });

        emit VehicleRegistered(plate, msg.sender, vehicleClass);
    }

    // ---------------------------------------------------------------
    // 2) WRITE + PAYABLE: pay motorway toll (needs MetaMask approval + ETH)
    // ---------------------------------------------------------------
    /// @param plate Registered number plate
    /// @param route 0 = M-2, 1 = M-1, 2 = M-3
    function payToll(string memory plate, uint8 route) public payable {
        Vehicle storage v = vehicles[plate];
        require(v.vehicleOwner != address(0), "Vehicle not registered");
        require(msg.sender == v.vehicleOwner, "Only the vehicle owner can pay toll");
        require(route < 3, "Invalid route");
        require(v.unpaidChallans < MAX_UNPAID_CHALLANS, "Too many unpaid challans: clear them first");

        uint256 fare = routeBaseFare[route] * classMultiplier[v.vehicleClass];
        require(msg.value == fare, "Incorrect toll amount");

        // Update records first, then send funds (safe order)
        v.tollsPaid += 1;
        v.totalTollWei += msg.value;

        tollCount += 1;
        tollRecords[tollCount] = TollRecord(plate, msg.sender, route, msg.value, block.timestamp);

        emit TollPaid(tollCount, plate, msg.sender, route, msg.value);

        (bool ok, ) = payable(owner).call{value: msg.value}("");
        require(ok, "Transfer to treasury failed");
    }

    // ---------------------------------------------------------------
    // 3) WRITE (authority only): issue an e-challan
    // ---------------------------------------------------------------
    /// @param plate Registered number plate
    /// @param violation 0 = Over-speeding, 1 = Lane violation, 2 = No seatbelt
    function issueChallan(string memory plate, uint8 violation) public {
        require(msg.sender == owner, "Only the authority can issue challans");
        require(vehicles[plate].vehicleOwner != address(0), "Vehicle not registered");
        require(violation < 3, "Invalid violation type");

        challanCount += 1;
        challans[challanCount] = Challan({
            plate: plate,
            violation: violation,
            fine: violationFine[violation],
            issuedAt: block.timestamp,
            paid: false,
            paidAt: 0
        });
        vehicles[plate].unpaidChallans += 1;

        emit ChallanIssued(challanCount, plate, violation, violationFine[violation]);
    }

    // ---------------------------------------------------------------
    // 4) WRITE + PAYABLE: pay an e-challan (needs MetaMask approval + ETH)
    // ---------------------------------------------------------------
    /// @param challanId Challan number (starts at 1)
    function payChallan(uint256 challanId) public payable {
        require(challanId >= 1 && challanId <= challanCount, "Challan does not exist");

        Challan storage c = challans[challanId];
        require(!c.paid, "Challan already paid");

        Vehicle storage v = vehicles[c.plate];
        require(msg.sender == v.vehicleOwner, "Only the vehicle owner can pay this challan");
        require(msg.value == c.fine, "Incorrect fine amount");

        // Update records first, then send funds (prevents duplicate payment)
        c.paid = true;
        c.paidAt = block.timestamp;
        v.unpaidChallans -= 1;

        emit ChallanPaid(challanId, c.plate, msg.sender, msg.value);

        (bool ok, ) = payable(owner).call{value: msg.value}("");
        require(ok, "Transfer to treasury failed");
    }

    // ---------------------------------------------------------------
    // 5) READ (view): get a vehicle's record. Free, no MetaMask popup.
    // ---------------------------------------------------------------
    function getVehicle(string memory plate)
        public
        view
        returns (
            address vehicleOwner,
            uint8 vehicleClass,
            uint256 registeredAt,
            uint256 tollsPaid,
            uint256 totalTollWei,
            uint256 unpaidChallans
        )
    {
        Vehicle memory v = vehicles[plate];
        require(v.vehicleOwner != address(0), "Vehicle not registered");
        return (v.vehicleOwner, v.vehicleClass, v.registeredAt, v.tollsPaid, v.totalTollWei, v.unpaidChallans);
    }
}
